﻿#include <windows.h>
#include <vector>
#include <string>

// ========== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ==========
HWND g_hwnd = nullptr;
HDC g_hdc = nullptr;
bool g_menuOpen = false;
bool g_skeleton = false;
bool g_box = false;
bool g_running = true;

// ========== СТРУКТУРА ИГРОКА ==========
struct Player {
    float x, y, z;
    float headX, headY, headZ;
};

// ========== РИСОВАНИЕ ЧЕРЕЗ GDI ==========
void DrawLineGDI(HDC hdc, int x1, int y1, int x2, int y2, COLORREF color) {
    HPEN pen = CreatePen(PS_SOLID, 2, color);
    HPEN oldPen = (HPEN)SelectObject(hdc, pen);
    MoveToEx(hdc, x1, y1, NULL);
    LineTo(hdc, x2, y2);
    SelectObject(hdc, oldPen);
    DeleteObject(pen);
}

void DrawRectGDI(HDC hdc, int x, int y, int w, int h, COLORREF color) {
    HBRUSH brush = CreateSolidBrush(color);
    HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, brush);
    Rectangle(hdc, x, y, x + w, y + h);
    SelectObject(hdc, oldBrush);
    DeleteObject(brush);
}

void DrawTextGDI(HDC hdc, const char* text, int x, int y, COLORREF color) {
    SetTextColor(hdc, color);
    SetBkMode(hdc, TRANSPARENT);
    TextOutA(hdc, x, y, text, strlen(text));
}

// ========== ЗАГЛУШКА (ТЕСТОВЫЕ ИГРОКИ) ==========
std::vector<Player> GetPlayers() {
    std::vector<Player> result;
    for (int i = 0; i < 5; i++) {
        Player p;
        p.x = 100 + i * 80;
        p.y = 200 + i * 30;
        p.z = 0;
        p.headX = p.x;
        p.headY = p.y - 80;
        p.headZ = p.z;
        result.push_back(p);
    }
    return result;
}

// ========== WH ==========
void RenderWH(HDC hdc) {
    auto players = GetPlayers();
    for (auto& p : players) {
        float sx = p.x, sy = p.y;
        float hx = p.headX, hy = p.headY;

        float height = abs(sy - hy);
        float width = height * 0.5f;

        if (g_box) {
            DrawLineGDI(hdc, sx - width / 2, sy, sx + width / 2, sy, RGB(0, 255, 0));
            DrawLineGDI(hdc, sx - width / 2, hy, sx + width / 2, hy, RGB(0, 255, 0));
            DrawLineGDI(hdc, sx - width / 2, hy, sx - width / 2, sy, RGB(0, 255, 0));
            DrawLineGDI(hdc, sx + width / 2, hy, sx + width / 2, sy, RGB(0, 255, 0));
        }

        if (g_skeleton) {
            DrawLineGDI(hdc, hx, hy, sx - width / 4, sy - height / 3, RGB(255, 0, 0));
            DrawLineGDI(hdc, hx, hy, sx + width / 4, sy - height / 3, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx - width / 4, sy - height / 3, sx, sy - height / 2, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx + width / 4, sy - height / 3, sx, sy - height / 2, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx - width / 4, sy - height / 3, sx - width / 2, sy, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx + width / 4, sy - height / 3, sx + width / 2, sy, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx - width / 2, sy, sx - width / 4, sy + height / 3, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx + width / 2, sy, sx + width / 4, sy + height / 3, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx - width / 4, sy + height / 3, sx, sy + height / 2, RGB(255, 0, 0));
            DrawLineGDI(hdc, sx + width / 4, sy + height / 3, sx, sy + height / 2, RGB(255, 0, 0));
        }
    }
}

// ========== МЕНЮ ==========
void DrawMenu(HDC hdc) {
    DrawRectGDI(hdc, 100, 100, 250, 200, RGB(30, 30, 30));
    DrawRectGDI(hdc, 100, 100, 250, 30, RGB(200, 50, 50));
    DrawTextGDI(hdc, "[ WH ]", 110, 105, RGB(255, 255, 255));

    DrawRectGDI(hdc, 115, 150, 15, 15, g_skeleton ? RGB(0, 255, 0) : RGB(100, 100, 100));
    DrawTextGDI(hdc, "Skeleton", 135, 148, RGB(255, 255, 255));

    DrawRectGDI(hdc, 115, 180, 15, 15, g_box ? RGB(0, 255, 0) : RGB(100, 100, 100));
    DrawTextGDI(hdc, "Box", 135, 178, RGB(255, 255, 255));

    POINT mouse;
    GetCursorPos(&mouse);
    ScreenToClient(g_hwnd, &mouse);
    if (GetAsyncKeyState(VK_LBUTTON) & 1) {
        if (mouse.x >= 115 && mouse.x <= 130 && mouse.y >= 150 && mouse.y <= 165) g_skeleton = !g_skeleton;
        if (mouse.x >= 115 && mouse.x <= 130 && mouse.y >= 180 && mouse.y <= 195) g_box = !g_box;
    }
}

// ========== ПОИСК CS2 ==========
HWND FindCS2() {
    HWND h = FindWindowA(NULL, "Counter-Strike 2");
    if (!h) h = FindWindowA(NULL, "CS2");
    return h;
}

// ========== ПОТОК ОТРИСОВКИ ==========
DWORD WINAPI RenderThread(LPVOID) {
    while (g_running) {
        g_hwnd = FindCS2();
        if (g_hwnd) {
            HDC hdc = GetDC(g_hwnd);
            if (hdc) {
                // Очищаем (для теста)
                RECT rect;
                GetClientRect(g_hwnd, &rect);

                // Меню
                if (g_menuOpen) {
                    DrawMenu(hdc);
                }

                // WH
                if (g_skeleton || g_box) {
                    RenderWH(hdc);
                }

                ReleaseDC(g_hwnd, hdc);
            }
        }
        Sleep(16); // 60 FPS
    }
    return 0;
}

// ========== ОБРАБОТКА КЛАВИШ ==========
DWORD WINAPI KeyThread(LPVOID) {
    while (g_running) {
        if (GetAsyncKeyState(VK_INSERT) & 1) {
            g_menuOpen = !g_menuOpen;
        }
        Sleep(50);
    }
    return 0;
}

// ========== ТОЧКА ВХОДА ==========
BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        CreateThread(NULL, 0, RenderThread, NULL, 0, NULL);
        CreateThread(NULL, 0, KeyThread, NULL, 0, NULL);
    }
    if (reason == DLL_PROCESS_DETACH) {
        g_running = false;
    }
    return TRUE;
}